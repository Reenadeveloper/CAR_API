﻿namespace CAR_API.Model
{
    public class Response
    {
        public string Regis_no { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public DateTime FIDate { get; set; }
        public DateTime LIDate { get; set; }
        public DateTime NIDate { get; set; }
       
    }
}

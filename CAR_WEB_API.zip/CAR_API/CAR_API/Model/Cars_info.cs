﻿namespace CAR_API.Model
{
    public class Cars_info
    {
        public string Regis_no { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public ICollection<TechnicalTest> Test { get; set; }
    }
    public class TechnicalTest
    {
        public int Id { get; set; }
        public string Regis_no { get; set; }
        public DateTime FIDate { get; set; }
        public DateTime LIDate { get; set; }
        public DateTime NIDate { get; set; }
    }
}

﻿using CAR_API.Data;
using CAR_API.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace CAR_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CarsController : Controller
    {
        private readonly CommanDbcs _db;

        public CarsController(CommanDbcs db)
        {
            _db = db;
        }

        [HttpGet]
        public IActionResult GetCars(string? reg)
        {
            SqlParameter[] prms = {new SqlParameter("@Regist_no", reg ?? (object)DBNull.Value)};

            var dt = _db.ExecuteProcedure("GetCars", prms);

            var cars = dt.AsEnumerable().Select(row => new Response
            {
                Regis_no = row["Registration_no"].ToString(),
                Brand = row["Brand"].ToString(),
                Model = row["Model"].ToString(),
                FIDate = Convert.ToDateTime(row["FirstInspectionDate"]),
                LIDate = Convert.ToDateTime(row["LastInspectionDate"]),
                NIDate = Convert.ToDateTime(row["NextInspectionDate"]),
               
            }).ToList();

            return Ok(cars);
        }

        
        [HttpPost]
        public IActionResult UpdateCars(List<Response> cars)
        {
            foreach (var c in cars)
            {
                SqlParameter[] prms =
                {
                new SqlParameter("@Regist_no", c.Regis_no),
                new SqlParameter("@LastInspectionDate", c.LIDate),
                new SqlParameter("@NextInspectionDate", c.NIDate),
              
            };

                _db.ExecuteNonQuery("UpdateCarTest", prms);
            }

            return Ok("Updated successfully");
        }
    }
}


﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace CAR_API.Data
{
    public class CommanDbcs
    {
        private readonly string _connectionString;

        public CommanDbcs(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("myConnection");
        }

        public DataTable ExecuteProcedure(string procName, SqlParameter[] parameters)
        {
            using SqlConnection con = new SqlConnection(_connectionString);
            using SqlCommand cmd = new SqlCommand(procName, con);
            cmd.CommandType = CommandType.StoredProcedure;

            if (parameters != null)
                cmd.Parameters.AddRange(parameters);

            using SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            da.Fill(dt);

            return dt;
        }
        public void ExecuteNonQuery(string procName, SqlParameter[] parameters)
        {
            using SqlConnection con = new SqlConnection(_connectionString);
            using SqlCommand cmd = new SqlCommand(procName, con);
            cmd.CommandType = CommandType.StoredProcedure;

            if (parameters != null)
                cmd.Parameters.AddRange(parameters);

            con.Open();
            cmd.ExecuteNonQuery();
        }
    }

}

